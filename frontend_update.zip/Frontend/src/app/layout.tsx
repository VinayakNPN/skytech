import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import DashboardLayout from "@/components/DashboardLayout";
import { ErrorBoundary } from "@/components/ErrorBoundary";
import { AuthProvider } from "@/contexts/AuthContext";
import GoogleAuthProvider from "@/components/GoogleAuthProvider";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "Skytech Program Management System",
  description: "Enterprise Manufacturing Workflow & Program Management Platform for Skytech Switchgear",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html
      lang="en"
      className={`${geistSans.variable} ${geistMono.variable} h-full antialiased`}
      suppressHydrationWarning
    >
      <head>
        <script
          dangerouslySetInnerHTML={{
            __html: `(function(){try{if(localStorage.getItem('skytech_sidebar_open')==='false'){document.documentElement.classList.add('sidebar-collapsed');}}catch(e){}})();`
          }}
        />
      </head>
      <body className="min-h-full flex flex-col bg-[#F8FAFC]" suppressHydrationWarning>
        <GoogleAuthProvider>
          <AuthProvider>
            <DashboardLayout>
              <ErrorBoundary>{children}</ErrorBoundary>
            </DashboardLayout>
          </AuthProvider>
        </GoogleAuthProvider>
      </body>
    </html>
  );
}
